import React from "react"

export const GlobalStateContect = React.createContext()
