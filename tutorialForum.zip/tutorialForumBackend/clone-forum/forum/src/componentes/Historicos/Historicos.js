

const Historicos = () => {
    return (
        <div>
            <h3>Artigos imperdíveis</h3>
            <p>Por favor, leia as regras antes de começar a trabalhar na plataforma. </p>
            <p>Visão e Estratégia da Alemhelp</p>

            <h3>Links em destaque</h3>
            <p>Chat Box</p>
         
        </div>
    )
}

export default Historicos