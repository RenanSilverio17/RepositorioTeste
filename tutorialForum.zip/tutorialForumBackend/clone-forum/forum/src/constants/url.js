
export const BASE_URL = `https://forum-backend-3zv0.onrender.com`