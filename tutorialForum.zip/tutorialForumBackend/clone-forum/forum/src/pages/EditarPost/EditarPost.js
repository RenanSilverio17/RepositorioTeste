import { useEffect } from "react";


const PerfilUser = () =>{



    return(
        <>
        <div>
            <img src="" />
            <p>Nome: </p>
            <p>Aniversário: </p>
            <p>Data de criação:</p>
        </div>

        <div>
            <p>Titulo</p>
            <p>Conteúdo</p>
            <p>Imagem</p>
            <button>Editar</button>
        </div>
        </>
    )
}

export default PerfilUser